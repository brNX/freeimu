var searchData=
[
  ['magn',['magn',['../classFreeIMU.html#adb282f340688d9589a1cf6011d46b749',1,'FreeIMU']]]
];
