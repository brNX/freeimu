Please go to TI's site (http://www.ti.com/tool/sw-ek-lm4f120xl), sign up, and download the StelarisWare software (SW-EK-LM4F120XL) for Stellaris LM4F120 LaunchPad Evaluation Board.
